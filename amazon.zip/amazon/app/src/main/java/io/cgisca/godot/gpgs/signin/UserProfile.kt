package io.cgisca.godot.gpgs.signin

data class UserProfile(var displayName: String?, var email: String?, var token: String?, var id: String?) {
}